<header class="header">
    <div class="container">
        <?php if(url('/')): ?>
            <div class="header__logo" onclick="location.reload();">T-Kalach</div>
        <?php else: ?>
            <a href="<?php echo e(url('/')); ?>" class="header__logo">T-Kalach</a>
        <?php endif; ?>
    </div>
</header>