<header class="header">
    <div class="container">
        @if(url('/'))
            <div class="header__logo" onclick="location.reload();">T-Kalach</div>
        @else
            <a href="{{ url('/') }}" class="header__logo">T-Kalach</a>
        @endif
    </div>
</header>